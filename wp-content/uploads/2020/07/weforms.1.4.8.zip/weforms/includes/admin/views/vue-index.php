<div class="wrap">
    <div id="wpuf-contact-form-app">
        <router-view></router-view>
    </div>
</div>
